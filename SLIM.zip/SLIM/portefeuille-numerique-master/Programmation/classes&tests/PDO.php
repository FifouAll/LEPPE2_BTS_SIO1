<?php
			//coordonnées de la base de données
	$config['displayErrorDetails'] = true;
	$config['addContentLengthHeader'] = false; 

	$config['db']['host']   = '172.19.0.10';
	$config['db']['user']   = 'sio';
	$config['db']['pass']   = '0550002D';
	$config['db']['dbname'] = 'portefeuilleNumerique';

?>